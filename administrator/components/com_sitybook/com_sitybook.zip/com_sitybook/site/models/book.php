<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
class SitybookModelsBook extends SitybookModelsDefault
{
    function __construct()
    {
        parent::__construct();
    }
 
    function store()
    {
      //  …
    }
 
    function getBook()
    {
      //  …
    }
 
    function getBooks()
    {
      //  …
    }
     
    function populateState()
    {
      //  …
    }
}
