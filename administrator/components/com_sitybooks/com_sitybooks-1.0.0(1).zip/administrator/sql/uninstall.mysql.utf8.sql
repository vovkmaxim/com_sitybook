DROP TABLE IF EXISTS `#__sitybooks_book`;
